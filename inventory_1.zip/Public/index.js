$(function(){
	var products = {};	//定义一个全局对象，用于存储每次添加的产品
	products.discount_before_total = 0;	//定义总价默认为0
	var i = 0;	//全局变量i，用于给对象中添加的每一个产品对象编号

	//获取当前日期时间对象
	var date = new Date();
	//设置订购日期的为当前日期
	$("#subscription_date").val(date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate());
	//页面首次加载获取 产品类别 渲染页面
	$.ajax({
		 type: "GET",						//请求方式
          url: "./server/index.php",			//请求url
          dataType: "json",					//返回数据的格式
          success: function(data){			//请求成功的回调函数
          	//定义产品类别的html字符串
          	var category = "<option value='0'>Choose a Category...</option>";
          	//循环遍历请求到的结果data
          	$.each(data,function(key,val){
          		//拼接产品类别的html字符串
          		category += "<option value='"+ val["category"] +"'>"+ val["category"] +"</option>";
          	});
          	//将产品类别的html字符串存入#category的select中
          	$("#category").html(category);
          }
	});
	//产品类别改变时触发
	$("#category").change(function(){
		var category = $(this).val();				//获取产品类别选中的值
		var customer = $("#customer").val();		//获取客户名称
		var please = $("#please").val();			//获取产品定价类型
		
		if(customer == 0 || please == 0){			//判断客户名称和产品定价类型是否已经选择
			alert("请先选择客户姓名和产品定价！");		//若未选择弹出提示信息
			$("#category").val("0");				//初始产品类别
			return false;
		}
		//判断产品类别是否重新选择为  “选择一个类别...”
		if(category == 0){
			//初始化part 、 product 、 price
			$("#part").html("<option value='0'>Choose a Part#...</option>");
			$("#product").html("<option value='0'>Choose a Product...</option>");
			$("#price").val("0");
			return false;
		}
		//异步请求获取 part的数据信息
		$.ajax({
			 type: "GET",
             url: "./server/index.php",
             dataType: "json",
             data: {						//请求数据，js对象格式
             	"category" : category
             },
             success: function(data){
             	var part = "<option value='0'>Choose a Part#...</option>";
             	$.each(data,function(key,val){
             		part += "<option value='"+ val["part"] +"'>"+ val["part"] +"</option>";
             	});
             	$("#part").html(part);
             }
		});
	});

	//Part改变时触发
	$("#part").change(function(){
		var category = $("#category").val();	//获取产品类别选中的值
		var part = $(this).val();				//获取part选中的值
		if(part == 0){
			$("#product").html("<option value='0'>Choose a Product...</option>");
			$("#price").val("0");
			return false;
		}
		$.ajax({
			 type: "GET",
             url: "./server/index.php",
             dataType: "json",
             data: {
             	"category"	: category,
             	"part"		: part
             },
             success: function(data){
             	// console.log(data);
             	var product = "<option value='0'>Choose a Product...</option>";
             	$.each(data,function(key,val){
             		product += "<option value='"+ val["name"] +"'>"+ val["name"] +"</option>";
             	});
             	$("#product").html(product);
             }
		});
	});

	$("#product").change(function(){
		var category = $("#category").val();
		var part = $("#part").val();
		var product = $(this).val();
		var please = $("#please").val();
		if(product == 0){
			$("#price").val("0");
			return false;
		}
		$.ajax({
			 type: "GET",
             url: "./server/index.php",
             dataType: "json",
             data: {
             	"category"	: category,
             	"part"		: part,
             	"product"	: product,
             	"please"	: please
             },
             success: function(data){
             	$.each(data,function(key,val){
             		$("#price").val(val[please]);
             	});
             }
		});
	});

	//btn_add点击事件
	$("#btn_add").click(function(){
		i++;	//编号加1
		var subscription_date = $("#subscription_date").val();	//订购日期
		var customer = $("#customer").val();	//客户名称
		var please = $("#please").val();		//产品定价方式
		var category = $("#category").val();	//产品类别
		var part = $("#part").val();			//产品型号
		var product = $("#product").val();		//产品名称
		var price = $("#price").val();			//产品价格
		var quantity = $("#quantity").val();	//订购数量

		products.customer = customer;
		products.subscription_date = subscription_date;
		products.please = please;
		products.customer = customer;
		products.customer = customer;


		$("#discount_val").val("");
		$("#discount_after_total").val("");
		$("#gst").val("");
		$("#tax_price").val("");
		$("#total_price").val("");

		$.ajax({
			 type: "GET",
             url: "./server/index.php",
             dataType: "json",
             data: {
             	"category"	: category,
             	"part"		: part,
             	"product"	: product,
             	"please"	: please,
             	"quantity"	: quantity
             },
             success: function(data){
             	//判断库存是否足够。 
             	if(data.length == 0){
             		alert("库存不足，重新选择库存！");
             		i--;	//编号加1
             		return false;
             	}

             	//初始化category、part 、 product 、 price
             	$("#category").val("0");
				$("#part").html("<option value='0'>Choose a Part#...</option>");
				$("#product").html("<option value='0'>Choose a Product...</option>");
				$("#price").val("0");


             	products["product-" + i] = {};
             	//定义用于拼接仓库地址的变量  使用循环拼接
             	var location = "";
             	$.each(data,function(key,val){
             		location +=  "<option value='"+ val["location"] +"'>"+ val["location"] +"</option>";
             	});
             	$("#list").removeClass("hide");
             	//添加一条产品信息到页面
             	$("#list").append("<tr><td><input type='text' value='"+ product +"' disabled='disabled'></td><td><input type='text' value='"+ quantity +"' disabled='disabled'></td><td><input type='text' value='"+ price +"' disabled='disabled'></td><td><select style='width: 100%;' name='location' id='location-"+ i +"'>"+ location +"</select></td></tr>");
             	
             	//添加一条产品信息到products对象
             	products["product-" + i].product = product;		//产品名称
             	products["product-" + i].quantity = quantity;	//产品数量	
             	products["product-" + i].price = price;			//产品价格

             	//小计计算 折扣前
				var sub_total = products["product-" + i].quantity * products["product-" + i].price;

				
				$("#sub_total").val(sub_total);
				//将小计存入对象
				products["product-" + i].sub_total = sub_total;
				console.log(products);


				// total before tax = 所有打印出来选中产品的总价
				var total_before_tax = products.discount_before_total + products["product-" + i].sub_total;
				$("#discount_before_total").val(total_before_tax);
				products.discount_before_total = total_before_tax;
             }
		});
		
		//折扣总额和税前总额计算
		$("#discount_val").keyup(function(){
			var discount_after_total = 0;	//折扣后的单件商品总额
			var discount_before_total = 0;	//所有商品的折扣后总额
			var discount_val = 0; //折扣值
			discount_val = $(this).val();	//折扣值
			var discount_type = $("input[type='radio']:checked").val();
			if(discount_type == "%"){
				discount_after_total = products["product-" + i].sub_total - (products["product-" + i].sub_total * (discount_val/100));
			}
			if(discount_type == "$"){
				discount_after_total = products["product-" + i].sub_total - discount_val;
			}
			products["product-" + i].discount_after_total = discount_after_total;	//折扣后的单件商品总价
			$("#discount_after_total").val(discount_after_total);

			//折扣后的所有商品总价计算
			for (var j = 1; j <= i; j++) {
				//判断是否算过折扣
				if(products["product-"+j].discount_after_total){
					discount_before_total += products["product-"+j].discount_after_total;
				}else{
					discount_before_total += products["product-"+j].sub_total;
				}
			}
			$("#discount_before_total").val(discount_before_total);
			products.discount_before_total = discount_before_total;
		});


		var tax_price = 0;	//定义税价
		var total_price = 0; //总计金额
		$("#gst").keyup(function(){
			var gst = $(this).val();
			tax_price = products.discount_before_total * (gst/100);	//计算税价
			$("#tax_price").val(tax_price);	//税价
			products.tax_price = tax_price;

			total_price = products.discount_before_total + products.tax_price;	//计算总计金额
			$("#total_price").val(total_price); //总计金额
			products.total_price = total_price;
			console.log(products);
		});

		//发货日期
		var date = new Date();
		date.setDate(date.getDate() + 5);
		var ship_date = date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate();
		$("#ship_date").val(ship_date);

		return false;
	});
	$("#form").submit(function(){
		if($("#payment_type").val() == "0"){
			alert("未选择付款方式!");
			return false;
		}

		//计算总计折扣
		var sum_price = 0;
		var s = "";	//拼接商品信息
		for (var j = 1; j <= i; j++) {
			//判断是否使用过折扣
			if(products["product-"+j].discount_after_total){
				//累加计算总折扣
				sum_price += products["product-"+j].sub_total - products["product-"+j].discount_after_total;
				//拼接有折扣的商品信息
				s += "产品:" + products["product-"+j].product + " 数量:" + products["product-"+j].quantity + " 价格:" + products["product-"+j].discount_after_total + " 优惠:" + (products["product-"+j].sub_total - products["product-"+j].discount_after_total) + " 仓库:" + $("#location-" + j).val() + "\n";
			}else{
				//拼接无折扣的商品信息
				s += "产品:" + products["product-"+j].product + " 数量:" + products["product-"+j].quantity + " 价格:" + products["product-"+j].sub_total + " 优惠:0" + " 仓库:" + $("#location-" + j).val() + "\n";
			}
		}
		alert(
			"客户姓名:" + products.customer + " 购物日期:" + products.subscription_date + " 价格类型:" + products.please + "\n" + 
			s +
			"税前总额:" + products.discount_before_total + "\n" +
			"总计税金:" + products.tax_price + "\n" +
			"支付方式:" + $("#payment_type").val() + "\n" +
			"总计金额:" + products.total_price + "\n" +
			"送达日期:" +  $('#ship_date').val() + "\n" +
			"售货员名称:"+ $("#payment").val() + "\n" + 
			"留言:" + CKEDITOR.instances.textarea.document.$.body.innerText
			);
		//提交后无需页面刷新 return false
		// return false;
	});
	
});