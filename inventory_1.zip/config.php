<?php
//数据库配置文件
return array(
	'db_type' => 'mysql',		//数据库类型
	'db_host' => '127.0.0.1',	//主机名
	'db_port' => '3306',		//端口号
	'db_user' => 'root',		//用户名
	'db_pass' => 'root',		//密码
	'db_name' => 'inventory',	//数据库名
	'charset' => 'utf8',		//字符集
);