<?php
//定义页面相应头
header("content-type:text/html;charset=utf-8");
//载入数据库连接文件
require_once ("common.php");



//判断网络请求是否有传值
if(isset($_GET["category"]) && isset($_GET["part"]) && isset($_GET["product"]) && isset($_GET['quantity'])){
	//获取前台通过get请求提交过来的值
	$category = $_GET["category"];
	$part = $_GET["part"];
	$product = $_GET['product'];
	$quantity = $_GET['quantity'];
	//定义查询的sql语句 
	$sql = "select location from inventory where category='{$category}' and part='{$part}' and name='{$product}' and quantity>={$quantity}";
	//执行sql语句查询数据
	$data = $pdo->query($sql)->fetchAll();
	//数据转为json返回给前台
	echo json_encode($data);

}else if(isset($_GET["category"]) && isset($_GET["part"]) && isset($_GET["product"])){
	$category = $_GET["category"];
	$part = $_GET["part"];
	$product = $_GET['product'];
	$please = $_GET['please'];
	//定义查询的sql语句 
	$sql = "select {$please} from inventory where category='{$category}' and part='{$part}' and name='{$product}' group by {$please}";
	$data = $pdo->query($sql)->fetchAll();
	echo json_encode($data);

}else if(isset($_GET["category"])&& isset($_GET["part"])){
	$category = $_GET["category"];
	$part = $_GET["part"];
	//定义查询的sql语句 
	$sql = "select name from inventory where category='{$category}' and part='{$part}' group by name";
	$data = $pdo->query($sql)->fetchAll();
	echo json_encode($data);

}else if(isset($_GET["category"])){

	$category = $_GET["category"];
	//定义查询的sql语句
	$sql = "select part from inventory where category='{$category}' group by part";
	$data = $pdo->query($sql)->fetchAll();
	echo json_encode($data);

}else{
	//定义查询的sql语句
	$sql = "select category from inventory group by category";
	$data = $pdo->query($sql)->fetchAll();
	echo json_encode($data);
}

//关闭pdo连接
$pdo = null;




