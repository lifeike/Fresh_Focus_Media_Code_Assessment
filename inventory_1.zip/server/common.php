<?php
//定义页面相应头
header("content-type:text/html;charset=utf-8");
//载入数据库配置文件生成全局变量config
$GLOBALS['config'] = require_once("../config.php");
//数据库配置信息
$dsn = $GLOBALS['config']['db_type'].":host:".$GLOBALS['config']['db_host'].";port=".$GLOBALS['config']['db_port'].";dbname=".$GLOBALS['config']['db_name'].";charset=".$GLOBALS['config']['charset'];
//创建pdo类的对象
$pdo = new PDO($dsn,$GLOBALS['config']['db_user'],$GLOBALS['config']['db_pass']);
// 清除全局变量config
$GLOBALS['config'] = "";