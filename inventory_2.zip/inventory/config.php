<?php
// database config
return array(
	'db_type' => 'mysql',		//datbase type
	'db_host' => '127.0.0.1',	//localhost
	'db_port' => '3306',		//port number
	'db_user' => 'root',		//username
	'db_pass' => 'root',		//password
	'db_name' => 'inventory',	//database name
	'charset' => 'utf8',		//charset settings
);
